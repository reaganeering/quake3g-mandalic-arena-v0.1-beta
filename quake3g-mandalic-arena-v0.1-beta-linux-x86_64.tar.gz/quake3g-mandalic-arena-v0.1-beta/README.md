
# ⚡ Quake3G: Mandalic Arena (v0.1 Public Beta)
### Sovereign Fixed-Point 11D Gaussian Splat 3D Engine & Serverless P2P Swarm
**Engineered by Ulshe AI & boredbrains.io**

> *"Unreal and Quake were foundational. Everything else was window dressing. This engine returns 3D computer graphics to pure, unbloated mathematical physics."*

---

## 🌟 The Breakthrough Matrix (What Makes This Different)

| Metric / Feature | Industry Standard 3D Engines | Quake3G: Mandalic Arena |
| :--- | :--- | :--- |
| **GPU / Driver Requirement** | Vulkan, DirectX 12, OpenGL, GPU Shaders | **Zero.** 100% Pure CPU Fixed-Point Math |
| **RAM Consumption** | 4,000 MB – 16,000 MB | **12 MB** total working footprint |
| **Binary Size** | 20 GB – 80 GB | **< 2.5 MB** single standalone executable |
| **Rendering Substrate** | Polygon Rasterization & Raytracing | **11D Gaussian Splatting** with Gelu falloff |
| **Multiplayer Architecture** | Centralized Paid Dedicated Servers | **Serverless P2P UDP Mesh** (Zero hosting cost) |
| **Anti-Cheat Verification** | Kernel drivers, behavioral heuristics | **60D Mandalic Cipher** (Kinematic Dissonance rejection) |
| **AI Gladiator Architecture** | Hardcoded behavior trees | **BYOAI Swarm Bridge** (Native `.mdo` / HTTP API / Port 8080) |
| **Security Auditing** | Manual fuzzing, third-party audits | **Formally Closed Topological Invariants** (Logic Arch Pro) |

---

## 🕹️ Controls & Navigation

- **W / A / S / D:** Quake 3 kinetic strafe-jumping movement.
- **Spacebar:** Jump (launch onto pads / low-gravity thruster).
- **Left-Click:** Aim & Fire Volumetric Helical Railgun (once focused).
- **Tab:** **Free Mouse Cursor** cleanly to interact with desktop/take screenshots without covering the screen! Click window again to resume 3D aim.
- **M / F1:** Toggle the **Sovereign Vault, Mandalic License & AI Gateway Modal**.
- **Q / E or Left/Right Arrows:** Keyboard smooth rotational gimbal.
- **Escape:** Exit arena immediately.

---

## 🧠 Bringing Your Own AI (BYOAI Gladiator)

Quake3G does not force you to run canned AI. The built-in Gladiator bot can be steered live by any LLM running on your local machine or swarm fleet:
1. Press **`M`** to open the Sovereign Vault.
2. Select **`LOCAL FORGE (127.0.0.1:8080)`** or **`SWARM MICT_MPC (127.0.0.1:8085)`**.
3. Click **`[ FETCH MODELS ]`** to discover all `.mdo` models on disk and live endpoints.
4. Select your model (`Jarvits`, `PascalChimeraV9`, `Qwen 2.5`, `Mistral`). The AI model will begin tactically piloting the Gladiator bot across the catwalk in real-time!

---

## 🌐 Serverless P2P Multiplayer

To play with friends or test across multiple computers:
1. Launch `quake3g_arena` on any computer on the same local network or VPN.
2. Each node automatically discovers peers via non-blocking directed broadcast on **UDP Port 8083**.
3. All player coordinates are wrapped in **`MICT_MPC` encrypted binary envelopes** and validated by the 8-petal Mandalic Cipher tumbler lock.
```
Run `chmod +x package_beta.sh && ./package_beta.sh`. Copy the tarball or binary over to your Acer and HP laptops, launch the match, and watch your multi-machine P2P swarm and BYOAI gladiator duel in pure Gaussian splats! 
```
