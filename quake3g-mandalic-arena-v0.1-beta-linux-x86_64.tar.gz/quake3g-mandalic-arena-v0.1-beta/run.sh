#!/usr/bin/env bash
cd "$(dirname "$0")"
./quake3g_arena
